#!/usr/bin/env bash
# 本地大模型部署自查（Linux / WSL）—— bash 检查.sh
echo "=== 显卡 ==="
if command -v nvidia-smi >/dev/null 2>&1; then
  nvidia-smi --query-gpu=name,driver_version,memory.total,memory.used --format=csv
else
  echo "没找到 nvidia-smi：要么不是 N 卡，要么驱动没装好"
fi
echo
echo "=== 内存 ==="
free -h 2>/dev/null | head -2
echo
echo "=== 磁盘 ==="
df -h / /home 2>/dev/null | head -4
echo
echo "=== 已装的推理工具 ==="
for c in ollama llama-server python3 docker nvcc; do
  if command -v $c >/dev/null 2>&1; then echo "  [有] $c -> $(command -v $c)"; else echo "  [无] $c"; fi
done
echo
echo "=== CUDA / 驱动兼容提示 ==="
if command -v nvidia-smi >/dev/null 2>&1; then
  drv=$(nvidia-smi --query-gpu=driver_version --format=csv,noheader | head -1)
  echo "驱动: $drv"
  echo "（驱动 550 及以下注意：官方预编译镜像里的 PTX 可能因为工具链太新而加载失败，报错形如"
  echo "  'the provided PTX was compiled with an unsupported toolchain'，这时要么换镜像，要么用同版本源码按你的架构重编）"
fi
echo
echo "把这份输出发给我，我告诉你能跑哪个模型、参数怎么设。"
