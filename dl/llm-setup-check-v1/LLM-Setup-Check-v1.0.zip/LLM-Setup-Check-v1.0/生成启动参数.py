#!/usr/bin/env python3
"""按你的显存和模型大小，算一组能跑的 llama.cpp 启动参数。"""
import argparse

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--vram", type=float, required=True, help="显存 GB，例如 11")
    ap.add_argument("--model-gb", type=float, required=True, help="模型文件大小 GB，例如 5.7")
    ap.add_argument("--ctx", type=int, default=32768, help="想要的上下文 token 数")
    a = ap.parse_args()
    # KV 缓存粗算：9B 模型 q8_0 KV 约 0.045 GB / 1K token（随层数/头数变，这里给保守值）
    kv_per_1k = 0.045
    kv = a.ctx / 1000 * kv_per_1k
    overhead = 0.8                      # 计算缓冲
    need = a.model_gb + kv + overhead
    print(f"显存 {a.vram} GB / 模型 {a.model_gb} GB / 上下文 {a.ctx}")
    print(f"估算占用：模型 {a.model_gb:.1f} + KV(q8_0) {kv:.1f} + 缓冲 {overhead:.1f} = {need:.1f} GB")
    if need <= a.vram - 0.5:
        print("→ 放得下，可以直接开这个上下文")
    else:
        shrink = int((a.vram - 0.5 - a.model_gb - overhead) / kv_per_1k * 1000)
        print(f"→ 放不下，建议把上下文降到 {max(4096, shrink // 1024 * 1024)} 左右，或者换更小的量化")
    print()
    print("参考启动命令：")
    print(f"  llama-server -m 模型.gguf --ctx-size {a.ctx} --n-gpu-layers 999 \\")
    print("    --cache-type-k q8_0 --cache-type-v q8_0 --flash-attn auto --jinja --parallel 1")

if __name__ == "__main__":
    main()
