# 本地大模型部署自查（Windows）—— 双击右键"用 PowerShell 运行"即可
$ErrorActionPreference = 'SilentlyContinue'
Write-Host "=== 显卡 ===" -ForegroundColor Cyan
if (Get-Command nvidia-smi -ErrorAction SilentlyContinue) {
  nvidia-smi --query-gpu=name,driver_version,memory.total,memory.used --format=csv
  Write-Host ""
  Write-Host "=== CUDA 驱动能力 ===" -ForegroundColor Cyan
  $d = (nvidia-smi --query-gpu=driver_version --format=csv,noheader)
  Write-Host "驱动版本: $d"
} else { Write-Host "没找到 nvidia-smi：要么不是 N 卡，要么驱动没装好" }
Write-Host ""
Write-Host "=== 内存 / 磁盘 ===" -ForegroundColor Cyan
$os = Get-CimInstance Win32_OperatingSystem
"内存总量: {0:N1} GB（可用 {1:N1} GB）" -f ($os.TotalVisibleMemorySize/1MB), ($os.FreePhysicalMemory/1MB)
Get-PSDrive -PSProvider FileSystem | Where-Object { $_.Used -ne $null } | ForEach-Object { "磁盘 {0}: 可用 {1:N1} GB" -f $_.Name, ($_.Free/1GB) }
Write-Host ""
Write-Host "=== 建议（按显存粗算，Q4 量化）===" -ForegroundColor Cyan
$mb = [int]((nvidia-smi --query-gpu=memory.total --format=csv,noheader,nounits) 2>$null | Select-Object -First 1)
if ($mb) {
  $gb = [math]::Round($mb/1024,1)
  Write-Host "你的显存: $gb GB"
  if ($gb -lt 6) { Write-Host "→ 适合 3B 以下的小模型（Q4）" }
  elseif ($gb -lt 9) { Write-Host "→ 适合 7B~9B（Q4），上下文建议 8K~16K" }
  elseif ($gb -lt 13) { Write-Host "→ 适合 9B~14B（Q4），上下文可开 32K（KV 用 q8_0）" }
  elseif ($gb -lt 20) { Write-Host "→ 适合 14B~32B（Q4），上下文 32K~64K" }
  else { Write-Host "→ 可以跑 32B 以上，或 9B 的长上下文（64K+）" }
}
Write-Host ""
Write-Host "把这份输出发给我，我告诉你能跑哪个模型、参数怎么设。" -ForegroundColor Green
